<?php
$host    = "localhost";
$user    = "root";
$pass    = "";
$db_name = "services";
$connection = mysqli_connect($host, $user, $pass, $db_name);
if(mysqli_connect_errno()){
    die("connection failed: "
        . mysqli_connect_error()
        . " (" . mysqli_connect_errno()
        . ")");
}
$email=$_POST['email'];
$query="delete FROM users WHERE email='".$email."'";
$result = mysqli_query($connection,$query);
if($result)
{   echo '<h1>If you have any queries please contact us-admin123@gmail.com</h1>'; 
	echo '<script>alert("Succesfully deleted")</script>';
}

?>
