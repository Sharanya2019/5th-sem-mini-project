<?php
$host    = "localhost";
$user    = "root";
$pass    = "";
$db_name= "services";
$name= $_POST['name'];

$address=$_POST['address'];
$gender=$_POST['gender'];
$contact=$_POST['num'];
$profession=$_POST['profession'];
$age=$_POST['age'];


$connection = mysqli_connect($host, $user, $pass, $db_name);
if(mysqli_connect_errno()){
    die("connection failed: "
        . mysqli_connect_error()
        . " (" . mysqli_connect_errno()
        . ")");
}

$query = "insert into employee values(DEFAULT,'$name','$gender','$address','$profession','$age','$contact')";
mysqli_query($connection,$query);
header("Location: add_success1.php");
mysqli_close($connection);
?>