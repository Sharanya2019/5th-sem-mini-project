<!DOCTYPE html>
<html><head>
<title>SERVICE BOX</title>
</head>
<script>

</script>
<style type="text/css">
p{color:teal;}


#top
            {  
                position:absolute;
                width:100%;
                height:40px;
                left:0px;
                background-color:cadetblue;
                z-index:20;
                padding-top: 0.3cm;}
</style>
<body bgcolor="white">
<table border="0" width="100%" bgcolor="cadetblue">
<tr>
<td><font color="white">ONLINE SERVICE BOX</td>
<th>   </th>
<th>   </th>
<th>   </th>

<th><a href="loginpage1.php"><font color="white">Logout</th>
<th><a href="cancelorder.php"><font color="white">CANCEL ORDER</th>
</tr>
</table>

</br>

<img src="services.png" width="100%" height="30%">
</br>
</br>
<table border="1" width="100%" bg color="white">
<tr>
<ul><div id="top">
                <h2 style="display:inline; color:white; padding-left: 15cm;">SERVICES</h2> 
                
            </div>
        </ul>
</br>
</br>
</br></br>
<tr>
<th><a href="tutoring.php"><img src="tutor_pic.png" width="45%"></a></th>
<th><a href="mechanic.php"><img src="mech_pic.png" width="45%"></a></th>
<th><a href="driver.php"><img src="driver_pic.png" width="45%"></a></th>
<th><a href="beaut.php"><img src="beau_pic.png" width="45%"></a></th>
<th><a href="photographer.php"><img src="photr_pic.png" width="45%"></a></th>
</tr>
<tr>
<th>Tutor</th>
<th>Mechanic</th>
<th>Car Driver</th>
<th>Beautician</th>
<th>Photographer</th>
</table></br></br>
<table border="1" width="100%" bg color="white">
<tr>
<th><a href="catering.php"><img src="catt_pic.png" width="45%"></a></th>
<th><a href="cleaning.php"><img src="maid_pic.png" width="45%"></a></th>
<th><a href="pandit.php"><img src="pandit_pic.png" width="35%"></a></th>
<th><a href="homeappl.php"><img src="homeappl_pic.png" width="35%"></a></th>
</tr>
<tr>
<th>Catering Services</th>

<th>Cleaning Service</th>
<th>Pandit services</th>
<th>Appliance Repair</th>
</table>
<br/></br>

<p><strong>CONTACT DETAILS: </strong>1223456789(whatsapp available)</br>        
<strong>Email-ID: </strong>abc1232gmail.com</p>
</br></br></br>


</body>
</html>