<html>
<link rel="stylesheet" href="signup.css">
<title>SERVICE BOX-Home</title>
<head>
   <div class = "h1">
       <div id="h11">
          <font face="Colonna MT">SERVICE BOX</font>
   </div>
</head>

<body>
   <div class ="b1">
       <span id="b11">SIGN UP</span>
            <form action="signup_check.php" method="POST">
<div class="b12">
    <font color="white">
USERNAME : <input name = "uname" type="email" placeholder="Email-id..." style = "width: 15em; height: 3em; border-radius: 10px;" required/><br><br>
PASSWORD : <input type="password" name = "pass1" placeholder="*******" style = "width: 15em; height: 3em; border-radius: 10px;" required/><br><br>
Confirm Password : <input type="password" name = "pass2" placeholder="*******" style = "width: 15em; height: 3em; border-radius: 10px" required/><br><br>

    </font>
<div>
<input type = "submit" value = "SUBMIT" style="margin-left: 50%; height: 3em; width: 10em; border-radius: 10px; border-style: none;"/>
</form>
</div>
</body>
</html>