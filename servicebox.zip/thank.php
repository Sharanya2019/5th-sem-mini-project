<!DOCTYPE html>
<html><head>
<title>Thank_you</title>
<style type="text/css">
.b14
{
	background-color: peachpuff;
	border-color: white;
	color: black;
	width: 10em;
	height: 30px;
	text-align: center;
	border-radius: 10px;
	margin-left: 12em;
	margin-top: 3em;
	font-size: 15;
	border-style: solid;
}

</style>
</head>
<body>
<h1 align="center">Your booking is successful</h1>
<h2 align="center">Thank you</h2>
<p>Details of booking will be sent for your email-id....For any queries please contact us</p>

<a href="cancelorder.php">
<div class="b14">CANCEL</div>
</a>
<?php
echo '<script>alert("Succesfully booked")</script>';
?>
</form>
</br>
</br>

</html>