<?php
$uname = $_POST['uname'];
$pass1 = $_POST['pass1'];
$pass2 = $_POST['pass2'];
$host    = "localhost";
$user    = "root";
$pass    = "";
$db_name = "services";

$connection = mysqli_connect($host, $user, $pass, $db_name);

if(mysqli_connect_errno()){
    die("connection failed: "
        . mysqli_connect_error()
        . " (" . mysqli_connect_errno()
        . ")");
}
$query = "SELECT * FROM login WHERE username='$uname'";
	$result = mysqli_query($connection,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
		
		if($pass1 == $pass2)
		{
			$check=mysqli_query($connection,"insert into login values('$uname','$pass1')");
			header("Location:home.php");
		}
		else 
			echo "Password not matching";
	

	
?>