<html>
<title>Service Box-Home</title>
<style type="text/css">
.h1
{
	width: 100vw;
	height: 10vh;
	background-color: black;
	opacity: 0.75;
}
#h11
{
	font-size: 50;
	margin-left: 36vw;
	color: gold;
	position:center;
}
body
{
	margin: 0;
	padding: 0;
	
	background-size: cover;
	background-position: center;
	background-repeat: no-repeat;
}


#b1text
{
	font-size: 30px;
	text-align: center;
	left: 8vw;
	top: 0vh;
}

.b5
{
	width: 40vw;
	height: 2vh;
	background-color: black;
	opacity: 0.85;
	color: cyan;
	margin-left: 20vw;
	margin-top: 3vh;
	position: relative;
	border-radius: 25px;
	padding: 25px;
}
#b1text
{
	font-size: 30px;
	text-align: center;
	left: 8vw;
	top: 0vh;
}

.h12
{
	margin-left: 85vw;
	margin-top: 3vh;
	font-size: 25px;
	background-color: white;
	width: 5em;
	text-align: center;
}	

.h1 a:link
{
	text-decoration: none;
	color: white;
}

.h2
{
	font-size: 48px;
	margin-left: 40vw;
	margin-top: 5vh;
	color: black;
	
}
</style>
<head>
<div class = "h1">
<div id="h11">
	<font face="Colonna MT">SERVICE BOX</font>
</div>
</head>
<div class="h12">
<a href="loginpage1.php">Log Out</a>
</div>
<body>
<div class="h2"><font face="ALGERIAN">WELCOME</font></div>
<a href="add_employee.php">
<div class = "b5">
<span id="b1text">Add Employee</span>
</div></a>


<a href="remove_emp.php">
<div class = "b5">
<span id="b1text">Remove Employee</span>
</div></a>
<a href="display_users.php">
<div class = "b5">
<span id="b1text">Display Users</span>
</div></a>
</div></a>
</body>
</html>


