<!DOCTYPE html>
<html>
<head>
<title>Form</title>
</head>
<body>
<form action="orderdetail.php" method="post">
Name:<input type="text" name="NAME" required/><br><br>
Email-id:<input type="email" name="email" required/><br><br>
Contact:<input type="tel" name="phone" pattern="[0-9]{10}" required/><br><br>

<table border="2">
<caption>Product Details</caption>
<tr>
	<th>Name</th>
	<th>Price</th>
	<th>Quantity</th>
</tr>
<tr>
	<td>item1</td>
	<td>20</td>
	<td><input type="number" name="quan1"></td>
</tr>
<tr>
	<td>item2</td>
	<td>30</td>
	<td><input type="number" name="quan2"></td>
</tr>
<tr>
	<td>item3</td>
	<td>5</td>
	<td><input type="number" name="quan3"></td>
</tr>
</table></br>
Payment:</br><input type="radio" id="debitcard" name="payment" value="debitcard">
<label for="Debitcard">Debitcard</label>
 </br><input type="radio" id="creditcard" name="payment" value="creditcard">
<label for="Creditcard">Credicard</label>
</br><input type="radio" id="NetBanking" name="payment" value="NetBanking">
<label for="NetBanking">NetBanking</label></br></br>
<input type="submit" value="Submit">
</form>
</body>
</html>