<html>
<link rel="stylesheet" href="artt.css"/>
<title>SERVICE BOX-Home</title>
<head>
<div class = "h1">
<div id="h11">
	<font face="Colonna MT">SERVICE BOX</font>
</div>
<br><br>
 <div id="h22">
 <font face="verdana">Our services are here for you!</font>
</div>
<body>
<div class = "b1">
<div id = "b11">LOGIN</div>
<form action="first.php" method="post">
<br>
<div id="b12">
<p style = "color: red; font-size: 25px; margin-top: 1vh;">Incorrect Username or password</p>
Username : <input type="text" name = "uname" placeholder="Username..." style="width: 60%; height: 40px; border-radius: 20px; border-style: none; padding-left: 10px;"/><br><br>
Password : <input type="password" name="pass" placeholder="Enter Password" style="width: 60%; height: 40px; border-radius: 20px; border-style: none; padding-left: 10px;"/>
</div>
<input type = "submit"/ class = "button1">
</form>
<div class = "b13">
<a href="">Forgot Password</a>
</div>
<a href="signup.php">
<div class="b14">SIGNUP</div>
</a>
</div>
</body>
</html>