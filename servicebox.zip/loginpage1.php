<html>
<title>Service Box-Home</title>
<style type="text/css">
.h1
{
	width: 100vw;
	height: 10vh;
	background-color: black;
	opacity: 0.75;
}
#h11
{
	font-size: 50;
	margin-left: 36vw;
	color: gold;
	position:center;
}
#b1text
{
	font-size: 30px;
	text-align: center;
	left: 8vw;
	top: 0vh;
}
.b1
{
	width: 40vw;
	height: 3vh;
	background-color: black;
	opacity: 0.85;
	color: cyan;
	margin-left: 20vw;
	margin-top:5vh;
	position: relative;
	border-radius: 25px;
	padding: 25px;
}

.b2
{
	width: 40vw;
	height: 2vh;
	background-color: black;
	opacity: 0.85;
	color: cyan;
	margin-left: 20vw;
	margin-top:5vh;
	position: relative;
	border-radius: 25px;
	padding: 25px;
}

	

.h1 a:link
{
	text-decoration: none;
	color: white;
}

.h2
{
	font-size: 48px;
	margin-left: 40vw;
	margin-top: 5vh;
	color: black;
	
}
</style>
<head>
<div class = "h1">
<div id="h11">
	<font face="Colonna MT">SERVICE BOX</font>
</div>
</head>

<body>
<div class="h2"><font face="ALGERIAN">WELCOME</font></div>
<a href="adminlogin.php">
<div class = "b1">
<span id="b1text">Admin Login</span>
</div></a>
<a href="first.php">
<div class = "b2">
<span id="b1text">User Login</span>
</div></a>

</body>
</html>

